import subprocess

# 调用a.py
p1 = subprocess.Popen(['python', 'postprocess.py'])
# 调用b.py
p2 = subprocess.Popen(['python', 'postprocess2.py'])
# 调用c.py
p3 = subprocess.Popen(['python', 'postprocess3.py'])
# 调用d.py
p4 = subprocess.Popen(['python', 'postprocess4.py'])

p5 = subprocess.Popen(['python', 'postprocess5.py'])
#
p6 = subprocess.Popen(['python', 'postprocess6.py'])

p7 = subprocess.Popen(['python', 'postprocess7.py'])

p8 = subprocess.Popen(['python', 'postprocess8.py'])

p9 = subprocess.Popen(['python', 'postprocess9.py'])

p10 = subprocess.Popen(['python', 'postprocess10.py'])


# 等待所有子进程执行完毕
p1.wait()
p2.wait()
p3.wait()
p4.wait()
p5.wait()
p6.wait()
p7.wait()
p8.wait()
p9.wait()
p10.wait()